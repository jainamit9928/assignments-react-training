import { createStore } from 'redux'
import todoApp from './reducers'

const store = () => {
    
          let store = createStore(todoApp);
    
  return store;
   console.log("store in store"+store);
   

}

export default store;