import React from 'react';
import TodoApp from './TodoApp';
import { Provider } from 'react-redux';
import { BrowserRouter, Route } from 'react-router-dom';
import PropTypes from 'prop-types';



export const Root = ({ store }) => (
        <Provider store={store}>
            <BrowserRouter>
                <Route path="/" component={ TodoApp } />
            </BrowserRouter>
        </Provider>
    );
Root.prototypes = {
    store:PropTypes.object.isRequired,
}
