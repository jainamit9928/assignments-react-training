module.exports.bar = function() { console.log("in bar"); }
module.exports.foo = "foo";
module.exports.bas = function() {
    console.log("bas called");
}