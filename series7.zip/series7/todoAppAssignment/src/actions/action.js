import * as types from '../constants/constants.js'
import _ from 'lodash';
import { createSelector } from 'reselect'

export const AddTodo = (todo) => ({type:types.ADD_TODO,text:todo})
export const deleteTodo = (id) => ({type:types.DELETE_TODO,id})
export const toggleTodo = (id) => ({type:types.TOGGLE_TODO,id})
export const setFilter = (filter) =>({type:types.SET_VISIBILITY_FILTER,filter})

const getVisibilityFilter = state => state.visibilityFilter
const getTodos = state => state.todos

export const getVisibleTodos = (todos, filter) => {
    console.log("todos are",todos,"filter are",filter)
    switch (filter) {
        case types.SHOW_ALL:
            return todos;

        case types.SHOW_COMPLETED:
            return _.filter(todos, ['completed', true]);

        case  types.SHOW_ACTIVE:
            return _.reject(todos, ['completed', true]);
    }
};
