import React, { Component } from 'react';
import TodoApp from '../components/TodoApp'


export default class TodoView extends Component {
  constructor(props){
    super(props);
    console.log("props in continaer",props)
  }
  
  render() {
 

    return (
      <div className='container'>
        <TodoApp  />
      </div>
    )
  
}
}


