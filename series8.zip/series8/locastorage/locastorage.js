console.log("-----------locastorage.js");

function serilazeObject(data) {
    var obj = data;
    console.log(Date.now())
    var expiryDate = Date.now() + 10 * 1000
    obj.expiryDate = expiryDate;
    var serilizedObj = JSON.stringify(obj);
    setToLocalStorage(obj.password, serilizedObj);
}


function setToLocalStorage(key, obj) {
    localStorage.setItem(key, obj);
}

function removeLocalStorageKey(key) {
    try {
        if (JSON.parse(localStorage.getItem(key))) {
            localStorage.removeItem(key);
        }
    } catch (error) {

    }
}

function getObject() {

    var elements = document.myform.elements;
    var obj = {};
    for (var i = 0; i < elements.length; i++) {
        var item = elements.item(i);
        obj[item.name] = item.value;
    }
    serilazeObject(obj);


}

for (var i = 0; i < localStorage.length; i++) {
    console.log(localStorage.getItem(localStorage.key(i)));
    console.log("current time" + Date.now() + "-----------" + "expriy time" + JSON.parse(localStorage.getItem(localStorage.key(i))).expiryDate);
    if ((parseInt(JSON.parse(localStorage.getItem(localStorage.key(i))).expiryDate) - parseInt(Date.now())) < 0) {
        removeLocalStorageKey(localStorage.key(i));
    }
}