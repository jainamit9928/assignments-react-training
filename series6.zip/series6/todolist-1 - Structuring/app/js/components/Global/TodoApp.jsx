import React from 'react';
import ReactDOM from 'react-dom';
import Todos from './Todos';
import Filters from './Filters';
import AddTodo from './AddTodo';
import getVisibleTodos from '../../actions/action';
const TodoApp = (props) => {
  const {todos,visibilityFilter} = props;

  return (
   
      <div>
      <AddTodo onAddTodo = {(text) => props.executeStore.dispatch({type:"ADD_TODO",text:text})} />
    <Todos todos ={getVisibleTodos(todos,visibilityFilter)} onTodoClick ={(id) => props.executeStore.dispatch({type:"TOGGLE_TODO",id}) }/>
   <Filters visibilityFilter = {visibilityFilter} onFilterClick = {(filter) => props.executeStore.dispatch({type:"SET_VISIBILITY_FILTER",filter}) } />
    </div>
  )
  
  }

export default TodoApp;


