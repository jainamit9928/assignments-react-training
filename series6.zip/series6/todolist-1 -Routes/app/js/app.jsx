import React from 'react';
import { Root } from './components/Global/root';
import ReactDOM from 'react-dom';
import { customStore } from './store';

const store = customStore();

ReactDOM.render(
 <Root store = {store} /> , document.getElementById('app'));


