import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';
import TodoApp from './components/Global/TodoApp'
import { createStore,applyMiddleware } from 'redux'
import todoApp from './reducers'
import Provider from './provider'
import {logger,crashReporter} from './middleware/middleware'


const store = createStore(todoApp,applyMiddleware(logger,crashReporter));
ReactDOM.render(
  <Provider store = {store}>
  <TodoApp  />
  </Provider>,
  document.getElementById('app') // eslint-disable-line
);

//store.subscribe(render);
