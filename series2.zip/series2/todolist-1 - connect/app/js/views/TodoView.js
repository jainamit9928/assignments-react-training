import React, { Component } from 'react';
import TodoApp from 'components/Global/TodoApp'


export class TodoView extends Component {
  constructor(props){
  
    super(props);
    this.store=this.props.customStore;
    
    
  }
  
  render() {
 

    return (
      <div className='About'>
      
        <TodoApp     />
       
      </div>
    );
  
}

 

}
