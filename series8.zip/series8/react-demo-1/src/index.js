import React from 'react';
import ReactDOM from 'react-dom'
//import {MyButton} from './button.component'
import Base from './button.component'
import Page from './keycheck.component'
import Data from './proptypes.component'
import {RoutesBase} from './button.component'
import {BrowserRouter as Router,Route,Link } from 'react-router-dom'
//console.log(MyButton);
ReactDOM.render(
    // <Base/>,
    
    <Router>
    <div>
        <ul>
        <li><Link to="/" >HOME</Link></li>
        <li><Link to="/keycheck">PropCheck</Link></li>
         <li><Link to="/data" >Data</Link></li>
          <li><Link to="/internalroute" >Internal Route</Link></li>
        </ul>
        <Route exact path="/" component={Base} />
        <Route  path="/keycheck" component={Page} />
        <Route  path="/data" component={Data} />
        <Route path="/internalroute" component={RoutesBase} />
     </div>

    </Router>
,document.getElementById("container")
    );

/*
setTimeout(function(){
ReactDOM.unmountComponentAtNode(document.getElementById("container"))
},3000)

lifecycle methods
component will Mount
button.component.js:60 in render Base
button.component.js:76 component child will Mount
button.component.js:110 in render Child
button.component.js:79 component child Did Mount
button.component.js:16 component Did Mount
button.component.js:38 shouldComponentUpdate newprops----
button.component.js:40 Object {val: "hi"}
button.component.js:42 Object {value: "Base Values"}
button.component.js:19 component Will Update---nextprops
button.component.js:20 Object {val: "hi"}
button.component.js:21 Object {value: "Base Values"}
button.component.js:60 in render Base
button.component.js:92 component child will recive props---nextprops
button.component.js:93 Object {baseValue: "Base Values", myprop: "this i default button", onBtnClicked: function}
button.component.js:101 shouldComponentUpdate child newprops----
button.component.js:103 Object {baseValue: "Base Values", myprop: "this i default button", onBtnClicked: function}
button.component.js:105 null
button.component.js:82 component child Will Update---nextprops
button.component.js:83 Object {baseValue: "Base Values", myprop: "this i default button", onBtnClicked: function}
button.component.js:84 null
button.component.js:110 in render Child
button.component.js:87 component child Did Update---prevprops
button.component.js:88 Object {baseValue: "Base Value", myprop: "this i default button", onBtnClicked: function}
button.component.js:89 null
button.component.js:24 component Did Update---prevprops
button.component.js:25 Object {val: "hi"}
button.component.js:26 Object {value: "Base Value"}
button.component.js:34 component unmountede
button.component.js:97 component child unmountede

*/

/*

componentWillMount -> 
render
ComponentDidMount ->
componentwiLLRECievwProps -> 
shouldComponentUpdate -->
component Will Update -> 
render
component Did Update ->
component unmountedd
*/

