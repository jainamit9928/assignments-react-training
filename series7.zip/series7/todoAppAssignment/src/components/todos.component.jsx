import React from 'react';
import PropTypes from 'prop-types';
import Todo from './todo.component'

const Todos = (props) => {
    console.log("in todos",props.todos)
   return ( <div> {props.todos.map((todo) => (<Todo todo = {todo} key = {todo.id}  onClick= {() => props.onTodoChange(todo.id)}  onChange ={() => props.onTodoDelete(todo.id)} />) )  }</div> )
}

export default Todos