import { combineReducers } from 'redux'
import todos from './reducer'
import visibilityFilter from './visibiltyFilter'
const todoAppReducer = combineReducers({
  todos,
  visibilityFilter
})

export default todoAppReducer;
