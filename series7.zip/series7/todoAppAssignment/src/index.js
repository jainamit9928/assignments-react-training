import React from 'react';
import ReactDOM from 'react-dom'
import {Provider} from 'react-redux'
import {createStore,applyMiddleware} from 'redux'
//import rootSaga from "./sagas/saga.js";
import createSagaMiddleware from "redux-saga";
import todoAppReducer from './reducers'
import TodoView from './container/todoView'
import {logger , crashReporter} from './middleware/middleware'
//import App from './containers/App';
const sagaMiddleware = createSagaMiddleware();
const store = createStore(todoAppReducer,applyMiddleware(logger,crashReporter));

//sagaMiddleware.run(rootSaga);
ReactDOM.render(
    <Provider store={store}>
        <TodoView />
    </Provider>
,document.getElementById("container")
    );


//for running test cases
//ReactDOM.render(<CheckboxWithLabel />, document.getElementById('root'));