// if object is used as a assignment context it is rest
// if object is uesed as a list context it spreads like argument

function foo(x,...args){
    //bar(42,...args1)
}
//args = rest parameter
//args1 is a spread parameter

function foo1(x,y,...rest){ return rest;}

var a = [1,2,3];

var b = [4,5,6];

foo1(...a,...b)
//MEANS
//rest =(4) [3, 4, 5, 6]
///
function bar(){ var a1= [2,4];var a2 = [6,8,10,12]; return foo(...a1,...a2);}
//a1 and a2 are destruting

//--here its strucuring
function foo(x,y,z,...rest){return [x,...rest]}; 

function foos(){
    return [1,2,3,5,6];
}
var [a,b,c] = foos();
var [a1,b1=2,c1,...args] =foos() || [];
var o ={};
[o.a,o.b=42,o.c,...o.args] =[1,2,3,4,5];

//SWAPPING
var x =10; var y=20;
//swap
[x,y] =[y,x];

var z =[1,2,3];
[x,y,...z] = [0,...z,4]
//z is now [2,3,4]

//even empty is allowed in destrucureing
[ , , ...z] = [0,...z,4]

var [a1,b1=2,c1,...args] = [1,2,3,[4,5,6]];
//undefined
//args
//[Array(3)]0: Array(3)length: 1__proto__: Array(0)

var [
    a1
    ,b1=2
    ,c1,
    [d,,e]
    ] = [1,2,3,[4,5,6]];
//undefined //d //4 //e //6


//destructing assignments will be whole array like x here
var x = [a1,b1] = [1,2,3,[4,5,6]];
//x
//(4) [1, 2, 3, Array(3)]

// we can chain  destrucure 

var [,,,[c,d]] = [a1,b1] = [1,2,3,[4,5,6]];
//c 4 ,d,5

//Object destrucuring
function test1(){
    return {a:1,b:2,c:3,d:{e:4}} }
    var {a,b:X,c=42,d:{e}} = test1() || {};
    var { a =10,b:X=42,c,d:{e},d:X,d:Z} = test1();
    //all X ,Z have an object d i.e. {e:3}

    //property names are always on left ,like X is on right and b on right

    // if d is not present a right side like
    var { a =10,b:X=42,c,d:{e}={},d:X,d:Z} = {a:1,b:2,c:3} 
    //then we have to assign a null object to d as above as we are checking for e also and that should have some empty object ref


    //TAG FN

    function currency(strings,...values){
    var str ="";
    console.log(strings);console.log(values);
    for(var i=0; i<strings.length; i++){ 
        if(i>0) {
            if(typeof values[i-1] == "number") {
                str +=values[i-1].toFixed(2);
            }
            else{
                str += values[i-1];
            }
        }
        str += strings[i]
    } 
    return str;
}
var msg = currency`Hello, ${name},Your order ${orderNumber} was $${total}.`;
//"Hello, kyle,Your order (#123) was $321.00."
//["Hello, ", ",Your order (#", ") was $", ".", raw: Array(4)]
//["kyle", "123", 321]
