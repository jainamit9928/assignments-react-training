import React from 'react';
import ReactDOM from 'react-dom';
import VisibleTodosList from './visibleTodoList';
import Filters from './Filters';
import AddTodo from './AddTodo';
const TodoApp = (props) => {
  const {todos,visibilityFilter} = props;

  return (
   
      <div>
      <AddTodo store = {props.executeStore}  />
   <VisibleTodosList store = {props.executeStore} />
   <Filters store = {props.executeStore} />
    </div>
  )
  
  }

export default TodoApp;


