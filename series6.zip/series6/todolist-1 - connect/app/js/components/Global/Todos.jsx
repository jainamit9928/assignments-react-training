import React from 'react';
import ReactDOM from 'react-dom';
import Todo from './Todo';



const Todos = ({todos,onTodoClick}) => {

console.log("todos are"+todos)
        return (
            <ul>
            {
                todos.map((todo,index) => <Todo key ={todo.id} {...todo} onClick = {() => onTodoClick(todo.id)}  />)
            }
            </ul>
        )

  



}
export default Todos;