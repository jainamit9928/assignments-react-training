import React from 'react';
import ReactDOM from 'react-dom';
import VisibleTodosList from './visibleTodoList';
import Filters from './Filters';
import AddTodo from './AddTodo';
const TodoApp = (props) => {
  const {todos,visibilityFilter} = props;

  return (
   
      <div>
      <AddTodo   />
   <VisibleTodosList />
   <Filters  />
    </div>
  )
  
  }

export default TodoApp;


