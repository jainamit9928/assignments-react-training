import React from 'react';
import PropTypes from 'prop-types'

const ListItem = (props) => (<li className="list-item">{props.item}</li>)

const List =({items}) => {

 return (<ul className ="list">
    {items.map((item,index) =>( <ListItem item={item} key={index} /> ))}
    
    </ul>)

};     //console.log("items are"+items);

    
      
const Body =(props) =>{
    let items = props.rowItems;
    return (
        <div>
            <h1>{props.header}</h1>
            <List items ={items} />
        </div>
    )
}

function Page(props,context){
    return(
        <div>
            <Body header ="My List" rowItems = {props.rowItems} />
        </div> 
    ) 
}
Page.propTypes ={
    rowItems:React.PropTypes.array.isRequired
}

Page.defaultProps ={
    rowItems:["l1","l2","l3","l4","l5","l6"]
}

export default Page;