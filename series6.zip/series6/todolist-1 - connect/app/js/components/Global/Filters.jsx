
import React from 'react';
import ReactDOM from 'react-dom';
import FilterLink from './FilterLink';

const Filters = (props) =>{

return (

 <p>
      Show :
       {' '}
    <FilterLink  filter ="SHOW_ALL" >ALL</FilterLink>
     {' '}
    <FilterLink  filter ="SHOW_ACTIVE"  >Active</FilterLink>
     {' '}
    <FilterLink filter ="SHOW_COMPLETED"  >Completed</FilterLink>
    </p>

)

}

export default Filters;