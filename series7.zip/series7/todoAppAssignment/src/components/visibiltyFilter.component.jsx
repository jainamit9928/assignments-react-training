import React from 'react';
import {connect} from 'react-redux';
import * as actions from '../actions/action'

const VisibiltyFilter = ({onSelectFilter}) => {
    let elem
    return (
    <form className ="container">
    <div className="form-group col-m-4">
      <select className="form-control" ref={node => {
                    elem = node }}  onChange={(e) => { e.preventDefault(); onSelectFilter(elem.value) }}>
        <option value="SHOW_ACTIVE">Active</option>
        <option value="SHOW_COMPLETED">Completed</option>
        <option value="SHOW_ALL" selected>All</option>
      </select>
    </div>
    </form>
   
    )
}

const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        onSelectFilter: (filter) => {
            dispatch(actions.setFilter(filter));
        }
    }
}
const VisibiltyFilterList =  connect(null,mapDispatchToProps)(VisibiltyFilter)
export default VisibiltyFilterList