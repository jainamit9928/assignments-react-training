const path = require('path');
const webpackValidator = require("webpack-validator");
//const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const webpack = require("webpack");
var VendorChunkPlugin = require('webpack-vendor-chunk-plugin');
const extractLess = new ExtractTextPlugin({
    filename: "[name].[contenthash].css"
});
module.exports = (env) => {
    console.log("enviorment is" + env);
    return {
        context: path.resolve('app'),
        entry: {
            vendor: ["lodash"],
            app: path.resolve(__dirname, 'app', 'js', 'app.jsx'),
            style: path.resolve(__dirname, 'app', 'css', 'main.less'),


        },
        output: {
            path: path.resolve(__dirname, 'dist'),
            filename: "[name].js"
        },
        resolve: {

            extensions: ['.js', '.jsx', 'less']
        },
        devServer: {
            port: 9000,
            contentBase: "react-training-25-07"
        },
        devtool: env.prod ? "source-map" : "eval",
        module: {
            rules: [{
                    test: [/\.js$/, /\.jsx$/],
                    exclude: /(node_modules)/,
                    use: {
                        loader: 'babel-loader',
                        options: {
                            presets: ['es2015', 'react']
                        }
                    }
                },
                {
                    test: /\.less$/,
                    use: ExtractTextPlugin.extract({ use: "css-loader", fallback: "style-loader" })
                },


            ]
        },
        plugins: [new webpack.optimize.CommonsChunkPlugin({
            name: "vendor",

            // filename: "vendor.js"
            // (Give the chunk a different name)

            minChunks: Infinity,
            // (with more entries, this ensures that no other module
            //  goes into the vendor chunk)
        }), new VendorChunkPlugin('vendor'), extractLess]
    }
}