import React from 'react';
import Data from './proptypes.component'
import Page from './keycheck.component'
import ReactDOM from 'react-dom'
import {BrowserRouter as Router,Route,Link } from 'react-router-dom'
class Base extends React.Component{
    constructor(props){
        super(props);
        this.state ={
            value:"Base Value"
        }
        
     
    }
    
    componentWillMount () {
        console.log("component will Mount");
    }
    componentDidMount() {
        
        console.log("component Did Mount");
    }
    componentWillUpdate(nextProps, nextState) {
        console.log("component Will Update---nextprops");
        console.log(nextProps);
         console.log(nextState);
    }
    componentDidUpdate(prevProps, prevState) {
          console.log("component Did Update---prevprops");
        console.log(prevProps);
         console.log(prevState);
    }
    componentWillReceiveProps (nextProps) {
         console.log("component will recive props---nextprops");
        console.log(nextProps);
        
    }
    componentWillUnmount() {
        console.log("component unmountede");
    }
    
    shouldComponentUpdate(newProps,newState){
        console.log("shouldComponentUpdate newprops----");
       
        console.log(newProps);
         
         console.log(newState);
       // return false;
       return true;
    }
    
    clearInput(){
         this.setState({
            value:""
        });
        console.log(this);
        // this.inputText.focus();
        ReactDOM.findDOMNode(this.inputText).focus();
    }
     onButtonClicked(e){
        console.log("Button Clicked"+e.target.id);
       this.state.value ="new value";
       console.log(this);
       //this.__proto__.render();
    }
    handleChange(e){
        //this.myState.value = e.target.value; // not allwoed
        this.setState({
            value:e.target.value
        })
    }
// ref will be a callback which will get an istance of dom element
//for getting refs in parent
//1) define call back where you want instance
//2) pass that call back instance to child as a prop and assign that prop as a ref.
//3) what exactly here happing is when mounting and unmounting this callback happens which paased an refrence to an element(dom instance)
    render(){
        console.log("in render Base");
        
        return (
        <div>
          <MyButton clearInput = {this.clearInput.bind(this)} onBtnClicked = {this.onButtonClicked.bind(this)} baseValue ={this.state.value}/> 
        <MyButton1 onBtnClicked1 = {this.onButtonClicked.bind(this)} baseValue1 ={this.state.value}/> 
        <TextBox textvalue ={this.state.value} handleChange ={this.handleChange.bind(this)} refInput={(el) => ( this.inputText = el)}/> 
           
        </div>
        )
    }
}
Base.defaultProps ={
    val:"hi"
}
//dont extend base 
//dont use inhertance normally
//class MyButton extends Base
const RoutesBase = ({match}) => (
        <div>
             
           <Route exact path={match.url} render = { () => ( <h3>Please select a topic</h3>) } />
            <ul>
                <li>
                <Link to={`${match.url}/rendering`} >
                Rendering Button 1
                </Link>
                </li>
                <li>
                <Link to={`${match.url}/components`} >
               components
                </Link>
                </li>
               
            </ul>
            
            <Route  path={`${match.url}/:topicId`} component={Topic} />
             
            </div>
    );

const Topic= ({match}) =>{
return(
    <div>
        <h3>Matched topic id is:{match.params.topicId}</h3>
    </div>
)
}

const MyButton1 = (props) =>{
    console.log(props);
return (<input type="button" id="btn" value={props.baseValue1} onClick={props.onBtnClicked1}/>)};


class MyButton extends React.Component{
    constructor(props){
        super(props);
    }
     componentWillMount () {
        console.log("component child will Mount");
    }
    componentDidMount() {
        console.log("component child Did Mount");
    }
    componentWillUpdate(nextProps, nextState) {
        console.log("component child Will Update---nextprops");
        console.log(nextProps);
         console.log(nextState);
    }
    componentDidUpdate(prevProps, prevState) {
          console.log("component child Did Update---prevprops");
        console.log(prevProps);
         console.log(prevState);
    }
    componentWillReceiveProps (nextProps) {
         console.log("component child will recive props---nextprops");
        console.log(nextProps);
        
    }
    componentWillUnmount() {
        console.log("component child unmountede");
    }
    
    shouldComponentUpdate(newProps,newState){
        console.log("shouldComponentUpdate child newprops----");
       
        console.log(newProps);
         
         console.log(newState);
       // return false;
       return true;
    }
    render(){
         console.log("in render Child");
        return <input type="button" id="btn" onClick ={this.props.clearInput} value={this.props.baseValue} />;
    }
}

MyButton.defaultProps ={
    myprop:"this i default button"
}
// here we are getting a callback fn in terms of prop named refInput
// mind it that refInput is a callback fn not a property
class TextBox extends React.Component{
    render(){
        return <input id="textBox" ref={this.props.refInput} type="text" value={this.props.textvalue} onChange ={this.props.handleChange} />
    }

}

//export {MyButton};
export default Base
export {RoutesBase}