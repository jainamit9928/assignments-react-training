
import React from 'react';
import ReactDOM from 'react-dom';
import FilterLink from './FilterLink';

const Filters = ({visibilityFilter,onFilterClick}) =>{

return (

 <p>
      Show :
       {' '}
    <FilterLink  filter ="SHOW_ALL" onClick = {onFilterClick} currentVisibiltyFilter ={visibilityFilter} >ALL</FilterLink>
     {' '}
    <FilterLink  filter ="SHOW_ACTIVE" onClick = {onFilterClick} currentVisibiltyFilter ={visibilityFilter}>Active</FilterLink>
     {' '}
    <FilterLink filter ="SHOW_COMPLETED" onClick = {onFilterClick} currentVisibiltyFilter ={visibilityFilter}>Completed</FilterLink>
    </p>

)

}

export default Filters;