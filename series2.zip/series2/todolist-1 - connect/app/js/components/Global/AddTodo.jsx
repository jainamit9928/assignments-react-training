import React from 'react';
import ReactDOM from 'react-dom';
const AddTodo = (props,{store}) => {
 let input;
 return (
<div>
  <input type="text" ref={node => {
      input=node} 
      }/>
     
     <button 
       
      onClick = {
        () => {
        store.dispatch({type:"ADD_TODO",text:input.value});
        input.value = "";
        }
        }>Add Todo</button> 


</div>


 )


}
AddTodo.contextTypes = {
store :React.PropTypes.object
}
export default AddTodo;