import React from 'react';
import VisibleTodoList from './visibleTodos.component';
import AddTodo from './AddTodo';
import VisibiltyFilterList from './visibiltyFilter.component'
const TodoApp = () => ( 
        <div>
            <AddTodo />
            <VisibleTodoList />
            <VisibiltyFilterList />
        </div>
    );
    



export default TodoApp;