import React from 'react';
const Todo = (props) => (
    <div className="row">
        <div className="col-md-12">
            <div className="col-md-4" style={{ textDecoration: props.todo.completed ? 'line-through' : 'none' }}>{props.todo.text}</div>
            <div className="col-md-4">
                <div className="checkbox">
                    <label><input onChange = {props.onClick}type="checkbox" id={props.todo.id}   value="" />
                    </label>
                </div>
            </div>
            <div className="col-md-4">
                <button type="button" className="btn btn-info btn-sm" onClick ={props.onChange} >
                    <span className="glyphicon glyphicon-remove-circle"></span> Remove
                </button>
            </div>
        </div>
    </div>

)

export default Todo;