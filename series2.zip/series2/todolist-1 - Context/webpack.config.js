const { resolve } = require('path');


module.exports = () => {
    return {
        context: resolve('src'),
        entry: path.join(__dirname, 'js', 'app.jsx'),
        output: {
            filename: 'app.js',
            path: path.resolve(__dirname, 'app', 'dist')
        },
        stats: {
            colors: true,
            reasons: true,
            chunks: true
        },
        devServer: {
            port: 9000,
            contentBase: path.join(__dirname, 'app')
        },
        resolve: {
            extensions: ['.js', '.jsx']
        },
        devServer: {
            contentBase: 'app',
            inline: true
        },
        module: {
            rules: [{
                test: [/\.js$/, /\.jsx$/],
                exclude: /(node_modules)/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['es2015', 'react']
                    }
                }
            }, {
                enforce: 'pre',
                test: [/\.js$/],
                exclude: /(node_modules)/,
                loader: 'eslint-loader'
            }, {
                test: /\.css$/,
                exclude: /(node_modules)/,
                use: ['style-loader', 'css-loader']
            }]
        }
    }
}