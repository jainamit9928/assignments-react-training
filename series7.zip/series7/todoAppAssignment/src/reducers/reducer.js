
import _ from 'lodash';
import * as types from '../constants/constants.js'
import { v4 } from 'node-uuid';
const todo = (state, action) => {
  console.log("in todo reducer")
    switch (action.type) {
        case types.ADD_TODO:
            return {
                id: v4(),
                text: action.text,
                completed: false,
            }
        case types.TOGGLE_TODO:
            if (state.id !== action.id) {
                return state
            }
            return Object.assign({}, state, { completed: !state.completed })
            
        default:
            return state;
    }
}

const todos = (state = [], action) => {
    console.log("in todos reducer")
    switch (action.type) {
        case types.ADD_TODO:
            return [...state,
            todo(undefined, action),
            ]
        case types.TOGGLE_TODO:
            return _.map(state, function (todoObject) {
                return todo(todoObject, action)
            })

         case types.DELETE_TODO:
         return _.reject(state,function(todoObject){
             return todoObject.id === action.id
         })   
        default:
            return state
    }
}


export default todos
