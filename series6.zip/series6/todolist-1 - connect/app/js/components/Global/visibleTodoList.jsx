import React from 'react';
import ReactDOM from 'react-dom';
import Todos from './Todos';
//import store from '../../store.js';
import getVisibleTodos from '../../actions/action';

export default class VisibleTodosList extends React.Component{
constructor(props){
super(props)

}
componentDidMount(){
    const {store} = this.context;
this.unsubscribe =store.subscribe(() => this.forceUpdate())
}
componentWillUnmount() {
    this.unsubscribe();
}

render(){
   const {store} = this.context; 
const {todos,visibilityFilter} =store.getState();
console.log(todos+visibilityFilter);
    return  (
    <Todos todos ={getVisibleTodos(todos,visibilityFilter)} onTodoClick ={(id) => store.dispatch({type:"TOGGLE_TODO",id}) }/>
    )
}


}

VisibleTodosList.contextTypes = {

    store :React.PropTypes.object
}