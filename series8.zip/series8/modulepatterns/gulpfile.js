var gulp = require('gulp');
//var browserify = require('browserify');
var browserify = require('gulp-browserify');

gulp.task("bundle", function() {
    console.log("bundle executed");
    gulp.src("./main.js").pipe(browserify({})).pipe(gulp.dest("./dist"));
    console.log("gulp completed");

})

gulp.task('default', function() {
    console.log("-----gulp---setup");
    gulp.watch("./main.js", ['bundle']);
})