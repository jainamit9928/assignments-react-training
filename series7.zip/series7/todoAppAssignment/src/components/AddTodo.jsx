import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import * as actions from '../actions/action'
const AddTodos = ({onAddTodo}) => {
    let input;
     let divStyle ={
        "margin":"100px"
    }
    return (
        <form style ={divStyle} className="col-md-3">
            <div className="form-group">
                <input className="form-control" type="text" ref={node => {
                    input = node
                }} />

                <button className="btn btn-success" onClick={(e) => { e.preventDefault(); onAddTodo(input.value); input.value = ""; }}>Add Todo</button>


            </div>

        </form>

    )
}

AddTodos.propTypes = {
    onAddTodo: PropTypes.func.isRequired
};

//creating container component
const AddTodo = connect(null, (dispatch) => {
    return {
        onAddTodo: (text) => {
            dispatch(actions.AddTodo(text));

        }
    }

})(AddTodos)
export default AddTodo;