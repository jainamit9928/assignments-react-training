import React from 'react';
import Todos from './Todos';
import {getVisibleTodos} from '../../actions/action';
import {connect} from 'react-redux'

const mapStateToProps = (state) => {
    return {

        todos: getVisibleTodos(state.todos, state.visibilityFilter)
    };

};

const mapDispatchToProps = (dispatch) => {
    return {

        onTodoClick: (id) => {
            dispatch({type: "TOGGLE_TODO", id});

        }
    };
};

//creating container component using TODOS as presentaional
const VisibleTodosList = connect(mapStateToProps, mapDispatchToProps)(Todos);

export default VisibleTodosList;
