import {connect} from 'react-redux';
import * as actions from '../actions/action'
import Todos from './todos.component'

const mapStateToProps = (state) => {
    console.log("in todos map state",state.todos);
    return {
        todos:actions.getVisibleTodos(state.todos,s)
    }
}
const mapDispatchToProps = (dispatch, ownProps) => {
    return {
        onTodoChange: (id) => {
            dispatch(actions.toggleTodo(id))
        },
        onTodoDelete:(id) => {
            dispatch(actions.deleteTodo(id))
        }
    }
}
const VisibleTodoList = connect(mapStateToProps,mapDispatchToProps)(Todos)

export default VisibleTodoList