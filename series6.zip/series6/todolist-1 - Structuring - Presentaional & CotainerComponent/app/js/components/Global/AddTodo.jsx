import React from 'react';
import ReactDOM from 'react-dom';
const AddTodo = (props) => {
 let input;
 return (
<div>
  <input type="text" ref={node => {
      input=node} 
      }/>
     
     <button 
       
      onClick = {
        () => {
        props.store.dispatch({type:"ADD_TODO",text:input.value});
        input.value = "";
        }
        }>Add Todo</button> 


</div>


 )


}

export default AddTodo;