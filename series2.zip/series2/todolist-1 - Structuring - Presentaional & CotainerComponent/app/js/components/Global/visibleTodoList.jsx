import React from 'react';
import ReactDOM from 'react-dom';
import Todos from './Todos';
//import store from '../../store.js';
import getVisibleTodos from '../../actions/action';

export default class VisibleTodosList extends React.Component{
constructor(props){
super(props)
}
componentDidMount(){
this.unsubscribe =this.props.store.subscribe(() => this.forceUpdate())
}
componentWillUnmount() {
    this.unsubscribe();
}

render(){
    
const {todos,visibilityFilter} =this.props.store.getState();
console.log(todos+visibilityFilter);
    return  (
    <Todos todos ={getVisibleTodos(todos,visibilityFilter)} onTodoClick ={(id) =>this.props.store.dispatch({type:"TOGGLE_TODO",id}) }/>
    )
}


}