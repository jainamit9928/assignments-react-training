var lib = require("./lib.js");
lib.bar();
lib.bas();


function curry(fn,n){
   

var n = Array.proptotype.slice.call(arguments,1);
if(n>fn.length){
    return function(){
        fn.apply(this,)
    }
}

}