import React from 'react';
import ReactDOM from 'react-dom';
import Todo from './Todo';
import PropTypes from 'prop-types';

const Todos = ({ todos, onTodoClick }) => {
    return (
        <ul>
            {todos && todos.map((todo, index) => <Todo key ={todo.id} {...todo} onClick= {() => onTodoClick(todo.id)}/>)}
        </ul>
    )
};
Todos.propTypes = {
    todos: PropTypes
        .arrayOf(PropTypes.shape({id: PropTypes.string.isRequired, completed: PropTypes.bool.isRequired, text: PropTypes.string.isRequired}).isRequired)
        .isRequired,
    onTodoClick: PropTypes.func.isRequired
}

export default Todos;