
import React from 'react';
import ReactDOM from 'react-dom';
import FilterLink from './FilterLink';

const Filters = (props) =>{

return (

 <p>
      Show :
       {' '}
    <FilterLink  filter ="SHOW_ALL" store ={props.store}>ALL</FilterLink>
     {' '}
    <FilterLink  filter ="SHOW_ACTIVE"  store ={props.store}>Active</FilterLink>
     {' '}
    <FilterLink filter ="SHOW_COMPLETED"  store ={props.store}>Completed</FilterLink>
    </p>

)

}

export default Filters;